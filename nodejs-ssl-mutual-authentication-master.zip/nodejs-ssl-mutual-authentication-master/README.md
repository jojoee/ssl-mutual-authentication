# nodejs-ssl-mutual-authentication

For more information on how to generate certificates and run the code, please refer to this [article](https://www.matteomattei.com/client-and-server-ssl-mutual-authentication-with-nodejs/)
